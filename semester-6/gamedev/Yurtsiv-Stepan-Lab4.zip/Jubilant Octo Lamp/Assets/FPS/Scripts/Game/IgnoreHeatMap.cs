﻿using UnityEngine;

namespace Unity.FPS.Game
{
    public class IgnoreHeatMap : MonoBehaviour
    {
    }
}