using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.InternalAPIEditorBridgeDev.005")]
[assembly: InternalsVisibleTo("Unity.InternalAPIEditorBridgeDev.002")]
